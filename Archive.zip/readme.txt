{\rtf1\ansi\ansicpg1252\cocoartf2580
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww31360\viewh19740\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 Burj Khalifa Projection-Mapping Submission Package\
\
Folder structure:\
- Project_Files/\
  - BurjKhalifa_MotionDesign.aep  (After Effects project file, to be created manually)\
  - Assets/  (vectors, textures, LUTs)\
- Renders/\
  - Segment_01_ProRes.mov\
  - Segment_02_ProRes.mov\
  - ... up to Segment_09_ProRes.mov\
- Calibration/\
  - LED_Calibration_LUT.cube\
  - Color_Test_Patterns/\
- Mapping/\
  - Resolume_Mesh_Settings.png\
  - Disguise_Mapping_Nodes.d3project\
- Audio/\
  - Soundtrack.wav  (if used)\
- CHECKSUMS.txt  (MD5 checksums for all rendered segments)\
\
README includes:\
1. Concept statement (max 300 words).\
2. List of segments and corresponding fa\'e7ade zones.\
3. Render settings and codecs used.\
4. On-site mesh warp adjustments and contact details.\
\
Please replace placeholder files with your actual project files before submission.\
}